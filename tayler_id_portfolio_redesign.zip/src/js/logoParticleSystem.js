/**
 * Enhanced Logo Particle System
 * Transforms the user's logo into an interactive 3D particle system
 * with advanced animation effects and AI assistant integration
 */

class LogoParticleSystem {
  constructor(containerId, logoPath) {
    this.containerId = containerId;
    this.logoPath = logoPath;
    this.particles = [];
    this.particleCount = 15000; // Increased for more detail
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.container = null;
    this.width = 0;
    this.height = 0;
    this.logoPoints = [];
    this.particleSystem = null;
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.targetRotation = { x: 0, y: 0 };
    this.currentRotation = { x: 0, y: 0 };
    this.interactionMode = 'idle'; // idle, active, speaking, reacting
    this.colors = {
      primary: new THREE.Color(0xff4d5a),
      secondary: new THREE.Color(0x00e5ff),
      neutral: new THREE.Color(0xffffff)
    };
    this.clock = new THREE.Clock();
    this.noiseOffset = 0;
    this.noiseStrength = 0;
    this.targetNoiseStrength = 0;
    
    // Initialize the system
    this.init();
    this.loadLogo();
  }
  
  init() {
    // Get container
    this.container = document.getElementById(this.containerId);
    if (!this.container) {
      console.error(`Container with ID ${this.containerId} not found`);
      return;
    }
    
    // Set dimensions
    this.width = this.container.clientWidth;
    this.height = this.container.clientHeight;
    
    // Create scene
    this.scene = new THREE.Scene();
    
    // Create camera
    this.camera = new THREE.PerspectiveCamera(
      75,
      this.width / this.height,
      1,
      10000
    );
    this.camera.position.z = 1000;
    
    // Create renderer
    this.renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true
    });
    this.renderer.setSize(this.width, this.height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.container.appendChild(this.renderer.domElement);
    
    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    this.scene.add(ambientLight);
    
    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(0, 10, 10);
    this.scene.add(directionalLight);
    
    // Add event listeners
    window.addEventListener('resize', this.onWindowResize.bind(this));
    this.container.addEventListener('mousemove', this.onMouseMove.bind(this));
    this.container.addEventListener('click', this.onClick.bind(this));
    this.container.addEventListener('touchstart', this.onTouchStart.bind(this), { passive: true });
    this.container.addEventListener('touchmove', this.onTouchMove.bind(this), { passive: true });
    
    // Start animation loop
    this.animate();
  }
  
  loadLogo() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      // Set canvas size to match image
      canvas.width = img.width;
      canvas.height = img.height;
      
      // Draw image to canvas
      ctx.drawImage(img, 0, 0);
      
      // Get image data
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      // Extract points from image
      this.extractPointsFromImage(data, canvas.width, canvas.height);
      
      // Create particle system
      this.createParticleSystem();
    };
    
    img.onerror = () => {
      console.error(`Failed to load logo from ${this.logoPath}`);
      // Create a fallback particle system
      this.createFallbackParticleSystem();
    };
    
    img.src = this.logoPath;
  }
  
  extractPointsFromImage(data, width, height) {
    const points = [];
    const threshold = 128; // Threshold for considering a pixel as part of the logo
    const sampleRate = 1; // Sample every nth pixel (increase for performance)
    
    for (let y = 0; y < height; y += sampleRate) {
      for (let x = 0; x < width; x += sampleRate) {
        const index = (y * width + x) * 4;
        const alpha = data[index + 3];
        
        // If pixel is not transparent (part of the logo)
        if (alpha > threshold) {
          // Normalize coordinates to center the logo
          const xNorm = (x / width - 0.5) * 800;
          const yNorm = (y / height - 0.5) * -800; // Flip Y axis
          
          points.push({
            x: xNorm,
            y: yNorm,
            z: 0,
            originalX: xNorm,
            originalY: yNorm,
            originalZ: 0
          });
        }
      }
    }
    
    // If we have more points than our particle count, sample them
    if (points.length > this.particleCount) {
      const step = Math.floor(points.length / this.particleCount);
      this.logoPoints = points.filter((_, index) => index % step === 0).slice(0, this.particleCount);
    } else {
      this.logoPoints = points;
      
      // If we have fewer points than our particle count, duplicate some
      while (this.logoPoints.length < this.particleCount) {
        const randomIndex = Math.floor(Math.random() * points.length);
        const point = { ...points[randomIndex] };
        
        // Add slight variation
        point.x += (Math.random() - 0.5) * 10;
        point.y += (Math.random() - 0.5) * 10;
        point.z += (Math.random() - 0.5) * 10;
        
        this.logoPoints.push(point);
      }
    }
  }
  
  createFallbackParticleSystem() {
    // Create a simple particle system if logo loading fails
    this.logoPoints = [];
    
    // Create a circular pattern
    for (let i = 0; i < this.particleCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = Math.random() * 300;
      
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      const z = (Math.random() - 0.5) * 100;
      
      this.logoPoints.push({
        x,
        y,
        z,
        originalX: x,
        originalY: y,
        originalZ: z
      });
    }
    
    // Create particle system
    this.createParticleSystem();
  }
  
  createParticleSystem() {
    // Create geometry
    const geometry = new THREE.BufferGeometry();
    
    // Create arrays for position and color
    const positions = new Float32Array(this.particleCount * 3);
    const colors = new Float32Array(this.particleCount * 3);
    const sizes = new Float32Array(this.particleCount);
    
    // Fill arrays
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      const point = this.logoPoints[i] || { x: 0, y: 0, z: 0 };
      
      // Position
      positions[i3] = point.x;
      positions[i3 + 1] = point.y;
      positions[i3 + 2] = point.z;
      
      // Color - default to primary color
      const color = this.colors.primary;
      colors[i3] = color.r;
      colors[i3 + 1] = color.g;
      colors[i3 + 2] = color.b;
      
      // Size - vary slightly for more natural look
      sizes[i] = Math.random() * 3 + 2;
    }
    
    // Add attributes to geometry
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
    
    // Create shader material for better performance and effects
    const material = new THREE.ShaderMaterial({
      uniforms: {
        pointTexture: { value: this.createParticleTexture() },
        time: { value: 0 }
      },
      vertexShader: `
        attribute float size;
        varying vec3 vColor;
        uniform float time;
        
        void main() {
          vColor = color;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = size * (300.0 / -mvPosition.z);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        uniform sampler2D pointTexture;
        varying vec3 vColor;
        
        void main() {
          gl_FragColor = vec4(vColor, 1.0) * texture2D(pointTexture, gl_PointCoord);
        }
      `,
      blending: THREE.AdditiveBlending,
      depthTest: false,
      transparent: true,
      vertexColors: true
    });
    
    // Create particle system
    this.particleSystem = new THREE.Points(geometry, material);
    this.scene.add(this.particleSystem);
    
    // Store reference to positions and colors for animation
    this.positions = positions;
    this.colors = colors;
    this.sizes = sizes;
    
    // Create target arrays for morphing
    this.targetPositions = new Float32Array(this.particleCount * 3);
    this.targetColors = new Float32Array(this.particleCount * 3);
    this.targetSizes = new Float32Array(this.particleCount);
    
    // Initialize target positions to logo shape
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      const point = this.logoPoints[i] || { x: 0, y: 0, z: 0 };
      
      this.targetPositions[i3] = point.originalX;
      this.targetPositions[i3 + 1] = point.originalY;
      this.targetPositions[i3 + 2] = point.originalZ;
      
      // Target color - default to primary
      const color = this.colors.primary;
      this.targetColors[i3] = color.r;
      this.targetColors[i3 + 1] = color.g;
      this.targetColors[i3 + 2] = color.b;
      
      // Target size - default to current size
      this.targetSizes[i] = sizes[i];
    }
  }
  
  createParticleTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createRadialGradient(
      canvas.width / 2,
      canvas.height / 2,
      0,
      canvas.width / 2,
      canvas.height / 2,
      canvas.width / 2
    );
    
    gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.2, 'rgba(255, 255, 255, 0.8)');
    gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.4)');
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    const texture = new THREE.Texture(canvas);
    texture.needsUpdate = true;
    return texture;
  }
  
  morphToLogoShape() {
    // Set target positions to original logo shape
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      const point = this.logoPoints[i] || { x: 0, y: 0, z: 0 };
      
      this.targetPositions[i3] = point.originalX;
      this.targetPositions[i3 + 1] = point.originalY;
      this.targetPositions[i3 + 2] = point.originalZ;
      
      // Set target color to primary
      const color = this.colors.primary;
      this.targetColors[i3] = color.r;
      this.targetColors[i3 + 1] = color.g;
      this.targetColors[i3 + 2] = color.b;
      
      // Set target size to original size
      this.targetSizes[i] = Math.random() * 3 + 2;
    }
    
    // Set noise strength
    this.targetNoiseStrength = 0;
  }
  
  morphToActiveState() {
    // Create a 3D formation that expands the logo
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      const point = this.logoPoints[i] || { x: 0, y: 0, z: 0 };
      
      // Add depth to the logo by varying Z based on position
      const distanceFromCenter = Math.sqrt(
        point.originalX * point.originalX + 
        point.originalY * point.originalY
      );
      
      const zOffset = Math.sin(distanceFromCenter * 0.01) * 150;
      
      this.targetPositions[i3] = point.originalX * 1.2;
      this.targetPositions[i3 + 1] = point.originalY * 1.2;
      this.targetPositions[i3 + 2] = zOffset;
      
      // Gradient color based on position
      const t = (point.originalY + 400) / 800; // Normalize to 0-1
      const color = new THREE.Color().lerpColors(
        this.colors.primary,
        this.colors.secondary,
        t
      );
      
      this.targetColors[i3] = color.r;
      this.targetColors[i3 + 1] = color.g;
      this.targetColors[i3 + 2] = color.b;
      
      // Increase size for more visual impact
      this.targetSizes[i] = Math.random() * 4 + 3;
    }
    
    // Set noise strength
    this.targetNoiseStrength = 0.2;
  }
  
  morphToSpeakingState() {
    // Create a dynamic speaking animation
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      const point = this.logoPoints[i] || { x: 0, y: 0, z: 0 };
      
      // Focus animation on lower part of logo (mouth/mustache area)
      const isMouthArea = point.originalY < 0;
      const scaleFactor = isMouthArea ? 1.3 : 1.1;
      
      this.targetPositions[i3] = point.originalX * scaleFactor;
      this.targetPositions[i3 + 1] = point.originalY * scaleFactor;
      this.targetPositions[i3 + 2] = isMouthArea ? 
        Math.sin(Date.now() * 0.01 + i * 0.1) * 80 : 
        point.originalZ;
      
      // Pulsing color effect
      const pulseIntensity = 0.5 + Math.sin(Date.now() * 0.005) * 0.5;
      const color = new THREE.Color().lerpColors(
        this.colors.primary,
        this.colors.secondary,
        pulseIntensity
      );
      
      this.targetColors[i3] = color.r;
      this.targetColors[i3 + 1] = color.g;
      this.targetColors[i3 + 2] = color.b;
      
      // Vary size based on position
      this.targetSizes[i] = isMouthArea ? 
        Math.random() * 5 + 3 : 
        Math.random() * 3 + 2;
    }
    
    // Set noise strength
    this.targetNoiseStrength = 0.4;
  }
  
  reactToMessage(message) {
    // Create a ripple effect through the particles
    const now = Date.now();
    
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      const point = this.logoPoints[i] || { x: 0, y: 0, z: 0 };
      
      // Calculate distance from center
      const distanceFromCenter = Math.sqrt(
        point.originalX * point.originalX + 
        point.originalY * point.originalY
      );
      
      // Create ripple effect
      const ripple = Math.sin(distanceFromCenter * 0.01 - now * 0.002) * 80;
      
      this.targetPositions[i3] = point.originalX * 1.4;
      this.targetPositions[i3 + 1] = point.originalY * 1.4;
      this.targetPositions[i3 + 2] = ripple;
      
      // Emotional color response based on message sentiment
      // This is a placeholder - in a real implementation, you'd analyze the message
      const excitementLevel = message.length / 100; // Simple proxy for excitement
      const color = new THREE.Color().lerpColors(
        this.colors.neutral,
        this.colors.secondary,
        Math.min(1, excitementLevel)
      );
      
      this.targetColors[i3] = color.r;
      this.targetColors[i3 + 1] = color.g;
      this.targetColors[i3 + 2] = color.b;
      
      // Increase size for more visual impact
      this.targetSizes[i] = Math.random() * 5 + 3;
    }
    
    // Set noise strength
    this.targetNoiseStrength = 0.6;
  }
  
  onWindowResize() {
    this.width = this.container.clientWidth;
    this.height = this.container.clientHeight;
    
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    
    this.renderer.setSize(this.width, this.height);
  }
  
  onMouseMove(event) {
    // Calculate mouse position in normalized device coordinates
    const rect = this.container.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / this.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / this.height) * 2 + 1;
    
    // Update target rotation based on mouse position
    this.targetRotation.y = this.mouse.x * 0.8;
    this.targetRotation.x = this.mouse.y * 0.5;
  }
  
  onTouchStart(event) {
    if (event.touches.length === 1) {
      const touch = event.touches[0];
      const rect = this.container.getBoundingClientRect();
      this.mouse.x = ((touch.clientX - rect.left) / this.width) * 2 - 1;
      this.mouse.y = -((touch.clientY - rect.top) / this.height) * 2 + 1;
      
      // Update target rotation based on touch position
      this.targetRotation.y = this.mouse.x * 0.8;
      this.targetRotation.x = this.mouse.y * 0.5;
    }
  }
  
  onTouchMove(event) {
    if (event.touches.length === 1) {
      const touch = event.touches[0];
      const rect = this.container.getBoundingClientRect();
      this.mouse.x = ((touch.clientX - rect.left) / this.width) * 2 - 1;
      this.mouse.y = -((touch.clientY - rect.top) / this.height) * 2 + 1;
      
      // Update target rotation based on touch position
      this.targetRotation.y = this.mouse.x * 0.8;
      this.targetRotation.x = this.mouse.y * 0.5;
    }
  }
  
  onClick() {
    // Toggle between idle and active states
    if (this.interactionMode === 'idle') {
      this.interactionMode = 'active';
      this.morphToActiveState();
    } else if (this.interactionMode === 'active') {
      this.interactionMode = 'speaking';
      this.morphToSpeakingState();
    } else {
      this.interactionMode = 'idle';
      this.morphToLogoShape();
    }
  }
  
  setMode(mode, message = '') {
    this.interactionMode = mode;
    
    switch (mode) {
      case 'idle':
        this.morphToLogoShape();
        break;
      case 'active':
        this.morphToActiveState();
        break;
      case 'speaking':
        this.morphToSpeakingState();
        break;
      case 'reacting':
        this.reactToMessage(message);
        break;
    }
  }
  
  applyNoise() {
    if (!this.particleSystem) return;
    
    const positions = this.particleSystem.geometry.attributes.position.array;
    const time = this.clock.getElapsedTime();
    this.noiseOffset += 0.01;
    
    // Smooth interpolation of noise strength
    this.noiseStrength += (this.targetNoiseStrength - this.noiseStrength) * 0.05;
    
    if (this.noiseStrength > 0) {
      for (let i = 0; i < this.particleCount; i++) {
        const i3 = i * 3;
        
        // Apply simplex noise
        const noiseX = this.simplex3(
          positions[i3] * 0.01, 
          positions[i3 + 1] * 0.01, 
          time * 0.5
        ) * this.noiseStrength * 20;
        
        const noiseY = this.simplex3(
          positions[i3] * 0.01 + 100, 
          positions[i3 + 1] * 0.01, 
          time * 0.5
        ) * this.noiseStrength * 20;
        
        const noiseZ = this.simplex3(
          positions[i3] * 0.01, 
          positions[i3 + 1] * 0.01 + 100, 
          time * 0.5
        ) * this.noiseStrength * 20;
        
        // Apply noise to positions
        positions[i3] += noiseX;
        positions[i3 + 1] += noiseY;
        positions[i3 + 2] += noiseZ;
      }
      
      this.particleSystem.geometry.attributes.position.needsUpdate = true;
    }
  }
  
  // Simple 3D simplex noise implementation
  simplex3(x, y, z) {
    const F3 = 1.0 / 3.0;
    const G3 = 1.0 / 6.0;
    
    const s = (x + y + z) * F3;
    const i = Math.floor(x + s);
    const j = Math.floor(y + s);
    const k = Math.floor(z + s);
    
    const t = (i + j + k) * G3;
    const X0 = i - t;
    const Y0 = j - t;
    const Z0 = k - t;
    
    const x0 = x - X0;
    const y0 = y - Y0;
    const z0 = z - Z0;
    
    // Determine which simplex we're in
    let i1, j1, k1;
    let i2, j2, k2;
    
    if (x0 >= y0) {
      if (y0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 1; k2 = 0; }
      else if (x0 >= z0) { i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 0; k2 = 1; }
      else { i1 = 0; j1 = 0; k1 = 1; i2 = 1; j2 = 0; k2 = 1; }
    } else {
      if (y0 < z0) { i1 = 0; j1 = 0; k1 = 1; i2 = 0; j2 = 1; k2 = 1; }
      else if (x0 < z0) { i1 = 0; j1 = 1; k1 = 0; i2 = 0; j2 = 1; k2 = 1; }
      else { i1 = 0; j1 = 1; k1 = 0; i2 = 1; j2 = 1; k2 = 0; }
    }
    
    // Offsets for second corner
    const x1 = x0 - i1 + G3;
    const y1 = y0 - j1 + G3;
    const z1 = z0 - k1 + G3;
    
    // Offsets for third corner
    const x2 = x0 - i2 + 2.0 * G3;
    const y2 = y0 - j2 + 2.0 * G3;
    const z2 = z0 - k2 + 2.0 * G3;
    
    // Offsets for last corner
    const x3 = x0 - 1.0 + 3.0 * G3;
    const y3 = y0 - 1.0 + 3.0 * G3;
    const z3 = z0 - 1.0 + 3.0 * G3;
    
    // Calculate gradient indices
    const gi0 = this.hash(i + this.hash(j + this.hash(k))) % 12;
    const gi1 = this.hash(i + i1 + this.hash(j + j1 + this.hash(k + k1))) % 12;
    const gi2 = this.hash(i + i2 + this.hash(j + j2 + this.hash(k + k2))) % 12;
    const gi3 = this.hash(i + 1 + this.hash(j + 1 + this.hash(k + 1))) % 12;
    
    // Calculate contribution from each corner
    let t0 = 0.6 - x0 * x0 - y0 * y0 - z0 * z0;
    let n0 = 0;
    if (t0 < 0) n0 = 0.0;
    else {
      t0 *= t0;
      n0 = t0 * t0 * this.dot(this.grad3[gi0], x0, y0, z0);
    }
    
    let t1 = 0.6 - x1 * x1 - y1 * y1 - z1 * z1;
    let n1 = 0;
    if (t1 < 0) n1 = 0.0;
    else {
      t1 *= t1;
      n1 = t1 * t1 * this.dot(this.grad3[gi1], x1, y1, z1);
    }
    
    let t2 = 0.6 - x2 * x2 - y2 * y2 - z2 * z2;
    let n2 = 0;
    if (t2 < 0) n2 = 0.0;
    else {
      t2 *= t2;
      n2 = t2 * t2 * this.dot(this.grad3[gi2], x2, y2, z2);
    }
    
    let t3 = 0.6 - x3 * x3 - y3 * y3 - z3 * z3;
    let n3 = 0;
    if (t3 < 0) n3 = 0.0;
    else {
      t3 *= t3;
      n3 = t3 * t3 * this.dot(this.grad3[gi3], x3, y3, z3);
    }
    
    // Add contributions from each corner
    return 32.0 * (n0 + n1 + n2 + n3);
  }
  
  hash(n) {
    return n % 12;
  }
  
  dot(g, x, y, z) {
    return g[0] * x + g[1] * y + g[2] * z;
  }
  
  // Gradient vectors for 3D simplex noise
  grad3 = [
    [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
    [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
    [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1]
  ];
  
  animate() {
    requestAnimationFrame(this.animate.bind(this));
    
    if (!this.particleSystem) {
      return;
    }
    
    // Update time uniform for shader
    if (this.particleSystem.material.uniforms) {
      this.particleSystem.material.uniforms.time.value = this.clock.getElapsedTime();
    }
    
    // Update rotation with smooth interpolation
    this.currentRotation.x += (this.targetRotation.x - this.currentRotation.x) * 0.05;
    this.currentRotation.y += (this.targetRotation.y - this.currentRotation.y) * 0.05;
    
    this.particleSystem.rotation.x = this.currentRotation.x;
    this.particleSystem.rotation.y = this.currentRotation.y;
    
    // Update speaking animation if in speaking mode
    if (this.interactionMode === 'speaking') {
      this.morphToSpeakingState();
    }
    
    // Apply noise to particles
    this.applyNoise();
    
    // Update particle positions with smooth interpolation
    const positions = this.particleSystem.geometry.attributes.position.array;
    const colors = this.particleSystem.geometry.attributes.color.array;
    const sizes = this.particleSystem.geometry.attributes.size.array;
    
    for (let i = 0; i < this.particleCount; i++) {
      const i3 = i * 3;
      
      // Update positions
      positions[i3] += (this.targetPositions[i3] - positions[i3]) * 0.02;
      positions[i3 + 1] += (this.targetPositions[i3 + 1] - positions[i3 + 1]) * 0.02;
      positions[i3 + 2] += (this.targetPositions[i3 + 2] - positions[i3 + 2]) * 0.02;
      
      // Update colors
      colors[i3] += (this.targetColors[i3] - colors[i3]) * 0.05;
      colors[i3 + 1] += (this.targetColors[i3 + 1] - colors[i3 + 1]) * 0.05;
      colors[i3 + 2] += (this.targetColors[i3 + 2] - colors[i3 + 2]) * 0.05;
      
      // Update sizes
      sizes[i] += (this.targetSizes[i] - sizes[i]) * 0.05;
    }
    
    this.particleSystem.geometry.attributes.position.needsUpdate = true;
    this.particleSystem.geometry.attributes.color.needsUpdate = true;
    this.particleSystem.geometry.attributes.size.needsUpdate = true;
    
    // Render scene
    this.renderer.render(this.scene, this.camera);
  }
}
